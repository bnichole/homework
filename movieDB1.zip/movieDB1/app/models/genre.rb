class Genre < ApplicationRecord
	has_many :actors
end
